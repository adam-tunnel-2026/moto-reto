# Moto Reto 3D: reparación preparada, pendiente de aplicar

No se ha podido acceder al repositorio: Git devolvió HTTP 403 y las herramientas de la conexión GitHub no están disponibles en esta sesión. No se han modificado archivos remotos, eliminado workflows, ejecutado Actions ni generado una APK. Adam Tunnel VPN no se ha modificado.

Este paquete está preparado a partir de los archivos guardados, no del estado actual de GitHub. No debe sustituir cambios remotos más recientes sin compararlos.

## Contenido

- Un único workflow activo: `.github/workflows/moto-reto-listo.yml`.
- Código Godot editable en `game/`, sin código comprimido incrustado en el workflow.
- Copias exactas del ZIP y workflow de partida en `backups/`, con extensión `.original` para que no se ejecuten. Estas copias no son una copia del repositorio remoto.
- Eliminadas del preset las opciones min_sdk y target_sdk usadas con la exportación sin Gradle. Se conserva Godot 4.4.1, Java 17 y Android SDK 35 de la configuración de partida. La exportación y compatibilidad deben confirmarse en Actions.
- Disparador actualizado al nombre correcto del workflow y a cambios en `game/`.
- APK disponible como artefacto y en una prerelease solo después de superar las comprobaciones del workflow.
- Comprobación que impide compilar este workflow en un repositorio distinto de `adam-tunnel-2026/moto-reto`.

## Verificación local

El ZIP original contiene 21 archivos y supera CRC. Su contenido coincide byte a byte con el proyecto incrustado en el workflow anterior, cuyo SHA256 es 8dfc9b1a6e3cce647cddffef43fb16063d9bd19c0a398ee6ad1c4842040c3845.

Pasan la comprobación de recursos, la identidad Android y el análisis sintáctico de los bloques Python del workflow. No se ha ejecutado Godot ni una compilación Android en esta sesión.

Pantalla vertical 540 × 960 y orientación 1 presentes en project.godot. Los eventos InputEventScreenTouch e InputEventScreenDrag están implementados; hay manejo de varios dedos para dirección, acelerador y freno. Requiere prueba en móvil. Los scripts de arte, paisaje y shaders quedan editables para mejorar los gráficos progresivamente.

## Aplicación pendiente en GitHub

1. Guardar primero una copia completa del repositorio remoto o una rama de respaldo.
2. Comparar este paquete con la versión actual del repositorio.
3. Aplicar `game/` y `.github/workflows/moto-reto-listo.yml`. Tras respaldarlos, retirar los demás workflows de `.github/workflows/`. Las copias deben quedar fuera de ese directorio.
4. Ejecutar Actions → Moto Reto - APK demo 3D → Run workflow.
5. Solo si termina en verde, descargar Moto-Reto-APK en Artifacts o la APK adjunta en Releases.

No se proporciona enlace de APK porque todavía no se ha generado ni verificado.
