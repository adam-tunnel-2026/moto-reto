extends SceneTree
const Race = preload("res://scripts/race.gd")
var checks: int = 0
var failures: int = 0

func check(ok: bool, message: String) -> void:
    checks += 1
    if not ok:
        failures += 1
        push_error(message)

func _initialize() -> void:
    _run.call_deferred()

func _run() -> void:
    var collision = Race.new(1)
    collision.traffic.assign([{"id": 1, "x": 0.0, "z": 3.1, "speed": 0.0, "color": 0, "passed": false}])
    collision.update(0.02, true, false)
    check(collision.ended and collision.crashed, "Colisión termina partida")
    var points: int = collision.points()
    collision.update(0.05, true, false)
    check(points == collision.points(), "Fin de partida congela puntos")
    var near = Race.new(2)
    near.traffic.assign([{"id": 1, "x": 1.85, "z": -2.9, "speed": 0.0, "color": 0, "passed": false}])
    near.update(0.02, true, false)
    check(near.passes == 1 and near.close_passes == 1 and not near.crashed, "Adelantamiento cercano válido")
    near.update(0.02, true, false)
    check(near.passes == 1, "No duplica premio")
    var finish = Race.new(3)
    for i in range(3700):
        finish.traffic.clear()
        finish.update(1.0 / 60.0, false, true)
    check(finish.ended and not finish.crashed, "Final a los 60 segundos")
    check(finish.speed >= 45.0 and finish.speed <= 190.0, "Velocidad limitada")
    var steering = Race.new(4)
    steering.target_x = 100.0
    steering.traffic.clear()
    for i in range(200):
        steering.traffic.clear()
        steering.update(1.0 / 60.0, true, false)
    check(steering.player_x <= 4.6, "Moto dentro de carretera")
    var clock = Race.new(5)
    clock.update(NAN, true, false)
    check(clock.elapsed == 0.0, "Rechaza tiempo inválido")
    clock.update(30.0, true, false)
    check(clock.elapsed <= 0.05, "No avanza al volver del fondo")
    for seed_value in range(100):
        var model = Race.new(seed_value)
        var rows: Dictionary = {}
        for car in model.traffic:
            rows[car.z] = int(rows.get(car.z, 0)) + 1
        for count in rows.values():
            check(int(count) <= 2, "Cada fila deja un carril libre")
    if failures == 0:
        print("MOTO_TEST_OK: ", checks, " comprobaciones")
    quit(1 if failures > 0 else 0)
