"""Packaging and offline source checks; not a replacement for Godot import/render tests."""
from pathlib import Path
import re
import configparser
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
ET.parse(root/'icon.svg')
for file in root.rglob('*.gd'):
    text=file.read_text()
    assert '\t' not in text, file
    for path in re.findall(r'(?:preload|load)\("res://([^\"]+)"\)',text):
        assert (root/path).is_file(), (file,path)
    assert not re.search(r'\b(?:HTTPRequest|HTTPClient|WebSocketPeer)\b',text),file
preset=(root/'export_presets.cfg').read_text()
assert 'version/code=2' in preset
assert 'package/unique_name="com.motoreto.demo"' in preset
assert 'permissions/internet=false' in preset
assert 'renderer/rendering_method="gl_compatibility"' in (root/'project.godot').read_text()
assert 'get_viewport().get_texture().get_image()' in (root/'scripts/main.gd').read_text()
print('PASS: resource references, Android identity, offline permissions, renderer and real screenshot path')
