extends RefCounted

const DURATION: float = 60.0
const CAR_HALF_WIDTH: float = 1.50
const COLLISION_DEPTH: float = 3.0
var traffic: Array[Dictionary] = []
var random := RandomNumberGenerator.new()
var speed: float = 90.0
var player_x: float = 0.0
var target_x: float = 0.0
var elapsed: float = 0.0
var distance: float = 0.0
var score: int = 0
var passes: int = 0
var close_passes: int = 0
var combo: int = 0
var best_combo: int = 0
var combo_time: float = 0.0
var ended: bool = false
var crashed: bool = false
var serial: int = 0
var next_row: float = 65.0
var next_close: bool = false

func _init(seed_value: int = 1) -> void:
    random.seed = seed_value
    _spawn(65.0)
    _spawn(130.0)
    _spawn(195.0)

func _spawn(z: float) -> void:
    var open_lane: int = random.randi_range(0, 2)
    var added: int = 0
    for lane in range(3):
        if lane != open_lane and (added == 0 or random.randf() > 0.5):
            serial += 1
            traffic.append({"id": serial, "x": float(lane - 1) * 3.5,
                "z": z, "speed": random.randf_range(45.0, 65.0),
                "color": random.randi_range(0, 4), "passed": false})
            added += 1

func update(dt: float, gas: bool, brake: bool) -> void:
    next_close = false
    if ended or not is_finite(dt) or dt <= 0.0:
        return
    dt = minf(dt, 0.05)
    elapsed = minf(DURATION, elapsed + dt)
    var acceleration: float = 28.0 if gas else (-12.0 if speed > 105.0 else 8.0)
    if brake:
        acceleration = -100.0
    speed = clampf(speed + acceleration * dt, 45.0, 190.0)
    target_x = clampf(target_x, -4.6, 4.6)
    player_x = move_toward(player_x, target_x, 7.0 * dt)
    var travel: float = speed * dt / 3.6
    distance += travel
    next_row -= travel
    if next_row <= 0.0:
        _spawn(235.0)
        next_row = random.randf_range(65.0, 90.0)
    combo_time = maxf(0.0, combo_time - dt)
    if combo_time == 0.0:
        combo = 0
    for i in range(traffic.size() - 1, -1, -1):
        var car: Dictionary = traffic[i]
        var previous: float = float(car.z)
        car.z = previous - (speed - float(car.speed)) * dt / 3.6
        var gap: float = absf(player_x - float(car.x))
        if minf(previous, float(car.z)) < COLLISION_DEPTH and maxf(previous, float(car.z)) > -COLLISION_DEPTH and gap < CAR_HALF_WIDTH:
            ended = true
            crashed = true
            return
        if not bool(car.passed) and previous >= -COLLISION_DEPTH and float(car.z) < -COLLISION_DEPTH:
            car.passed = true
            passes += 1
            if gap < 2.1:
                combo = mini(5, combo + 1)
                best_combo = maxi(best_combo, combo)
                combo_time = 4.0
                close_passes += 1
                score += 100 * combo
                next_close = true
            else:
                score += 30
        if float(car.z) < -18.0 or float(car.z) > 320.0:
            traffic.remove_at(i)
    if elapsed >= DURATION:
        ended = true

func points() -> int:
    return score + int(distance)
