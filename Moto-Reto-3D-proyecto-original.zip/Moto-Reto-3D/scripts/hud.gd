extends CanvasLayer

signal play_requested
signal pause_requested
signal volume_changed(value: float)
var gas: bool = false
var brake: bool = false
var gas_control: Button
var brake_control: Button
var points_label := Label.new()
var info_label := Label.new()
var speed_label := Label.new()
var close_label := Label.new()
var menu := PanelContainer.new()
var title_label := Label.new()
var description := Label.new()
var play_button: Button
var sound_slider := HSlider.new()
var root := Control.new()
var safe_margin := MarginContainer.new()

func _ready() -> void:
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)
    safe_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    safe_margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(safe_margin)
    var layout := VBoxContainer.new()
    layout.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layout.add_theme_constant_override("separation", 10)
    safe_margin.add_child(layout)
    var top := HBoxContainer.new()
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    top.add_theme_constant_override("separation", 8)
    layout.add_child(top)
    _panel_label(top, points_label, "PUNTOS\n0", 26, 1.0)
    _panel_label(top, info_label, "RÉCORD 0\n60 s", 20, 1.4)
    var pause := _button("Ⅱ", Color("203b4ad9"))
    pause.custom_minimum_size = Vector2(54, 70)
    pause.pressed.connect(func() -> void: pause_requested.emit())
    top.add_child(pause)
    close_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    close_label.add_theme_font_size_override("font_size", 25)
    close_label.add_theme_color_override("font_color", Color("ffe7a1"))
    layout.add_child(close_label)
    var spacer := Control.new()
    spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
    spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layout.add_child(spacer)
    var driving := HBoxContainer.new()
    driving.add_theme_constant_override("separation", 8)
    driving.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layout.add_child(driving)
    var stop := _button("FRENO", Color("9b3031e8"))
    brake_control = stop
    stop.custom_minimum_size = Vector2(125, 92)
    stop.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    stop.button_down.connect(func() -> void: brake = true)
    stop.button_up.connect(func() -> void: brake = false)
    driving.add_child(stop)
    speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    speed_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    speed_label.custom_minimum_size.x = 110
    speed_label.add_theme_font_size_override("font_size", 30)
    speed_label.add_theme_color_override("font_color", Color.WHITE)
    _panel_label(driving, speed_label, "90\nkm/h", 27, 1.0)
    var go := _button("ACELERAR", Color("287c4fe8"))
    gas_control = go
    go.custom_minimum_size = Vector2(155, 92)
    go.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    go.button_down.connect(func() -> void: gas = true)
    go.button_up.connect(func() -> void: gas = false)
    driving.add_child(go)
    var hint := Label.new()
    hint.text = "Desliza para conducir · 3D / Demo 0.2"
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.add_theme_font_size_override("font_size", 15)
    hint.add_theme_color_override("font_color", Color("e4eef3"))
    layout.add_child(hint)
    var shade := StyleBoxFlat.new()
    shade.bg_color = Color("102634ef")
    shade.set_corner_radius_all(22)
    shade.content_margin_left = 25
    shade.content_margin_right = 25
    shade.content_margin_top = 27
    shade.content_margin_bottom = 27
    menu.add_theme_stylebox_override("panel", shade)
    root.add_child(menu)
    menu.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    menu.offset_left = -235
    menu.offset_right = 235
    menu.offset_top = -190
    menu.offset_bottom = 190
    var items := VBoxContainer.new()
    items.add_theme_constant_override("separation", 18)
    menu.add_child(items)
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.add_theme_font_size_override("font_size", 30)
    items.add_child(title_label)
    description.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    description.add_theme_font_size_override("font_size", 18)
    description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    description.custom_minimum_size = Vector2(400, 75)
    items.add_child(description)
    play_button = _button("JUGAR", Color("287c4f"))
    play_button.custom_minimum_size.y = 65
    play_button.pressed.connect(func() -> void: play_requested.emit())
    items.add_child(play_button)
    var volume_label := Label.new()
    volume_label.text = "Motor y efectos · volumen"
    volume_label.add_theme_font_size_override("font_size", 17)
    items.add_child(volume_label)
    sound_slider.max_value = 1.0
    sound_slider.step = 0.05
    sound_slider.custom_minimum_size.y = 35
    sound_slider.value_changed.connect(func(v: float) -> void: volume_changed.emit(v))
    items.add_child(sound_slider)
    var credits := _button("Licencias", Color("203b4a"))
    credits.add_theme_font_size_override("font_size", 14)
    credits.pressed.connect(_credits)
    items.add_child(credits)
    get_viewport().size_changed.connect(update_safe_area)
    update_safe_area()

func update_safe_area() -> void:
    var screen: Vector2i = DisplayServer.screen_get_size()
    var area: Rect2i = DisplayServer.get_display_safe_area()
    var top: int = 20
    var bottom: int = 20
    if OS.has_feature("android") and screen.y > 0:
        var ratio: float = 960.0 / float(screen.y)
        top = maxi(20, int(area.position.y * ratio) + 10)
        bottom = maxi(20, int((screen.y - area.end.y) * ratio) + 10)
    safe_margin.add_theme_constant_override("margin_left", 18)
    safe_margin.add_theme_constant_override("margin_right", 18)
    safe_margin.add_theme_constant_override("margin_top", top)
    safe_margin.add_theme_constant_override("margin_bottom", bottom)

func _button(words: String, color: Color) -> Button:
    var b := Button.new()
    b.text = words
    b.add_theme_font_size_override("font_size", 21)
    b.focus_mode = Control.FOCUS_NONE
    var style := StyleBoxFlat.new()
    style.bg_color = color
    style.set_corner_radius_all(20)
    style.border_color = Color("ffffff40")
    style.set_border_width_all(2)
    var pressed: StyleBoxFlat = style.duplicate()
    pressed.bg_color = color.lightened(0.2)
    b.add_theme_stylebox_override("normal", style)
    b.add_theme_stylebox_override("hover", style)
    b.add_theme_stylebox_override("pressed", pressed)
    b.add_theme_color_override("font_color", Color.WHITE)
    return b

func _panel_label(parent: Node, label: Label, words: String, size: int, stretch: float) -> void:
    var panel := PanelContainer.new()
    panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    panel.size_flags_stretch_ratio = stretch
    var style := StyleBoxFlat.new()
    style.bg_color = Color("102634ce")
    style.set_corner_radius_all(18)
    style.content_margin_left = 15
    style.content_margin_right = 15
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    panel.add_theme_stylebox_override("panel", style)
    parent.add_child(panel)
    label.text = words
    label.add_theme_font_size_override("font_size", size)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.add_child(label)

func show_menu(title: String, details: String, button_text: String) -> void:
    title_label.text = title
    description.text = details
    play_button.text = button_text
    menu.show()
    gas = false
    brake = false

func hide_menu() -> void:
    menu.hide()

func refresh(points: int, best: int, remaining: int, speed: float, combo: int) -> void:
    points_label.text = "PUNTOS\n%d" % points
    info_label.text = "RÉCORD %d\nTIEMPO %d s" % [best, remaining]
    speed_label.text = "%d\nkm/h" % int(speed)
    close_label.text = "¡ADELANTAMIENTO! ×%d" % combo if combo > 0 else ""

func driving_role(pos: Vector2) -> String:
    if gas_control.get_global_rect().has_point(pos):
        return "gas"
    if brake_control.get_global_rect().has_point(pos):
        return "brake"
    return "steer"

func _credits() -> void:
    var dialog := AcceptDialog.new()
    dialog.title = "Motor Godot · licencia MIT"
    var content := RichTextLabel.new()
    content.text = FileAccess.get_file_as_string("res://LICENSE-GODOT.txt")
    content.custom_minimum_size = Vector2(400, 360)
    content.add_theme_font_size_override("normal_font_size", 15)
    dialog.add_child(content)
    root.add_child(dialog)
    dialog.confirmed.connect(dialog.queue_free)
    dialog.canceled.connect(dialog.queue_free)
    dialog.popup_centered(Vector2i(440, 420))
