extends Node3D

const Art = preload("res://scripts/art.gd")
var art := Art.new()
var roadside := Node3D.new()
var markings := Node3D.new()
var asphalt := ShaderMaterial.new()
var sea := ShaderMaterial.new()
var landscape_time: float = 0.0

func _ready() -> void:
    var env := Environment.new()
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color("4386bc")
    sky_mat.sky_horizon_color = Color("c5d9de")
    sky_mat.ground_bottom_color = Color("364a45")
    sky_mat.ground_horizon_color = Color("c5d9de")
    sky_mat.sky_curve = 0.18
    sky.sky_material = sky_mat
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.65
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.tonemap_exposure = 1.1
    env.fog_enabled = true
    env.fog_light_color = Color("a4becd")
    env.fog_density = 0.0020
    var world := WorldEnvironment.new()
    world.environment = env
    add_child(world)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-43.0, -37.0, 0.0)
    sun.light_color = Color("fff0d7")
    sun.light_energy = 1.5
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 80.0
    sun.shadow_bias = 0.035
    add_child(sun)
    asphalt.shader = load("res://shaders/asphalt.gdshader")
    var road := PlaneMesh.new()
    road.size = Vector2(10.5, 310.0)
    art.mesh(self, road, asphalt, Vector3(0.0, 0.01, -140.0))
    var grass := art.material(Color("52633d"), 0.0, 1.0)
    var soil := art.material(Color("8b8165"), 0.0, 1.0)
    art.box(self, Vector3(14.5, 0.20, 310.0), Vector3(0.0, -0.12, -140.0), soil)
    art.box(self, Vector3(25.0, 0.25, 320.0), Vector3(-18.0, -0.17, -140.0), grass)
    art.box(self, Vector3(18.0, 0.20, 320.0), Vector3(16.0, -0.23, -140.0), grass)
    sea.shader = load("res://shaders/water.gdshader")
    var water := PlaneMesh.new()
    water.size = Vector2(850.0, 950.0)
    art.mesh(self, water, sea, Vector3(365.0, -5.0, -330.0))
    var sand := PlaneMesh.new()
    sand.size = Vector2(50.0, 400.0)
    art.mesh(self, sand, art.material(Color("b9ad8b")), Vector3(40.0, -4.5, -150.0))
    var rock := art.material(Color("777b68"), 0.0, 1.0)
    var far_hill := art.material(Color("6c8584"), 0.0, 1.0)
    for i in range(8):
        var z: float = -float(i) * 55.0
        art.ellipsoid(self, Vector3(32.0, 25.0 + float(i % 3) * 8.0, 49.0), Vector3(-47.0, -10.0, z), rock, 24)
        art.ellipsoid(self, Vector3(43.0, 22.0, 38.0), Vector3(90.0 + float(i) * 17.0, -9.0, -240.0 - float(i) * 40.0), far_hill, 24)
    add_child(markings)
    var white := art.material(Color("dddccd"), 0.0, 0.9)
    # Batched meshes keep lane markers cheap on mobile.
    var stripe_mesh := BoxMesh.new()
    stripe_mesh.size = Vector3(0.13, 0.012, 4.5)
    var batch := MultiMesh.new()
    batch.transform_format = MultiMesh.TRANSFORM_3D
    batch.mesh = stripe_mesh
    batch.instance_count = 54
    var mi := MultiMeshInstance3D.new()
    mi.multimesh = batch
    mi.material_override = white
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    markings.add_child(mi)
    for i in range(27):
        for lane in range(2):
            batch.set_instance_transform(i * 2 + lane, Transform3D(Basis.IDENTITY, Vector3(-1.75 + float(lane) * 3.5, 0.025, -float(i) * 12.0)))
    for side in [-1.0, 1.0]:
        art.box(self, Vector3(0.15, 0.015, 310.0), Vector3(side * 5.05, 0.026, -140.0), white)
        # Galvanised roadside barriers with narrow rails.
        for height in [0.58, 0.75]:
            art.box(self, Vector3(0.09, 0.14, 310.0), Vector3(side * 6.0, height, -140.0), art.metal)
    add_child(roadside)
    var random := RandomNumberGenerator.new()
    random.seed = 2030
    var greens: Array[StandardMaterial3D] = [art.material(Color("334d2a")), art.material(Color("4c6332")), art.material(Color("657b3d"))]
    var bark := art.material(Color("635a45"))
    for i in range(16):
        var z: float = -float(i) * 20.0
        for side in [-1.0, 1.0]:
            art.box(roadside, Vector3(0.10, 0.78, 0.10), Vector3(side * 6.0, 0.38, z), art.metal)
            var x: float = side * random.randf_range(9.5, 18.0)
            var height: float = random.randf_range(3.3, 6.2)
            var trunk := art.rod(roadside, Vector3(x, 0.0, z), Vector3(x, height * 0.75, z), 0.14, bark)
            trunk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
            for j in range(4):
                var pos := Vector3(x + random.randf_range(-1.1, 1.1), height - random.randf_range(0.0, 1.0), z + random.randf_range(-1.2, 1.2))
                var leaves := art.ellipsoid(roadside, Vector3(1.4, 1.7, 1.3), pos, greens[j % greens.size()], 12)
                leaves.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
            # Low shrubs soften the roadside instead of a row of identical circles.
            art.ellipsoid(roadside, Vector3(1.4, 0.55, 1.2), Vector3(side * 8.0, 0.20, z + 7.0), greens[i % greens.size()], 12)

func move_world(distance: float, dt: float) -> void:
    landscape_time += dt
    markings.position.z = fmod(distance, 12.0)
    roadside.position.z = fmod(distance, 20.0)
    asphalt.set_shader_parameter("travel", distance)
    sea.set_shader_parameter("clock", landscape_time)
