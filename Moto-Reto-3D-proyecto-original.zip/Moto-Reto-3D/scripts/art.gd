extends RefCounted

var paint_colors: Array[Color] = [Color("2769a1"), Color("d0d6dc"), Color("a81c26"), Color("434852"), Color("b99c47")]
var rubber := material(Color("15191e"), 0.0, 0.94)
var metal := material(Color("8b99a5"), 0.8, 0.27)
var dark := material(Color("1b2430"), 0.3, 0.45)
var glass := material(Color("203f54"), 0.65, 0.16)
var red := material(Color("bf202b"), 0.55, 0.24)
var leather := material(Color("171e27"), 0.0, 0.62)
var headlight := material(Color("fff2ce"), 0.0, 0.24)
var taillight := material(Color("f5292b"), 0.1, 0.26)

func material(color: Color, metallic: float = 0.0, roughness: float = 0.8) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metallic
    m.roughness = roughness
    return m

func mesh(parent: Node3D, geometry: Mesh, mat: Material, pos: Vector3) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.mesh = geometry
    n.material_override = mat
    n.position = pos
    parent.add_child(n)
    return n

func box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
    var g := BoxMesh.new()
    g.size = size
    return mesh(parent, g, mat, pos)

func ellipsoid(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, detail: int = 16) -> MeshInstance3D:
    var g := SphereMesh.new()
    g.radius = 1.0
    g.height = 2.0
    g.radial_segments = detail
    g.rings = maxi(6, detail / 2)
    var n := mesh(parent, g, mat, pos)
    n.scale = size
    return n

func rod(parent: Node3D, a: Vector3, b: Vector3, radius: float, mat: Material) -> MeshInstance3D:
    var g := CylinderMesh.new()
    g.top_radius = radius
    g.bottom_radius = radius
    g.height = a.distance_to(b)
    g.radial_segments = 10
    var n := mesh(parent, g, mat, (a + b) * 0.5)
    var direction: Vector3 = (b - a).normalized()
    n.quaternion = Quaternion(Vector3.UP, direction)
    return n

func torus(parent: Node3D, inner: float, outer: float, pos: Vector3, mat: Material) -> MeshInstance3D:
    var g := TorusMesh.new()
    g.inner_radius = inner
    g.outer_radius = outer
    g.rings = 24
    g.ring_segments = 12
    var n := mesh(parent, g, mat, pos)
    n.rotation.z = PI / 2.0
    return n

# Smooth longitudinal sections: z, half-width, centre height, vertical radius.
func loft(parent: Node3D, sections: Array[Vector4], mat: Material) -> MeshInstance3D:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    st.set_smooth_group(0)
    var count: int = 20
    for row in range(sections.size() - 1):
        for i in range(count):
            var a: Vector3 = _ring(sections[row], i, count)
            var b: Vector3 = _ring(sections[row], i + 1, count)
            var c: Vector3 = _ring(sections[row + 1], i, count)
            var d: Vector3 = _ring(sections[row + 1], i + 1, count)
            for v in [a, b, c, b, d, c]:
                st.add_vertex(v)
    for side in [0, sections.size() - 1]:
        var section: Vector4 = sections[side]
        var centre := Vector3(0.0, section.z, section.x)
        for i in range(count):
            var a: Vector3 = _ring(section, i, count)
            var b: Vector3 = _ring(section, i + 1, count)
            st.add_vertex(centre)
            st.add_vertex(b if side == 0 else a)
            st.add_vertex(a if side == 0 else b)
    st.generate_normals()
    return mesh(parent, st.commit(), mat, Vector3.ZERO)

func _ring(s: Vector4, i: int, count: int) -> Vector3:
    var theta: float = TAU * float(i) / float(count)
    # Superellipse rounds the corners without turning the body into a sphere.
    var x: float = signf(cos(theta)) * pow(absf(cos(theta)), 0.60)
    var y: float = signf(sin(theta)) * pow(absf(sin(theta)), 0.75)
    return Vector3(x * s.y, s.z + y * s.w, s.x)

func wheel(parent: Node3D, pos: Vector3, radius: float, motorcycle: bool = false) -> Node3D:
    var root := Node3D.new()
    root.position = pos
    parent.add_child(root)
    torus(root, radius * 0.69, radius, Vector3.ZERO, rubber)
    torus(root, radius * 0.55, radius * 0.70, Vector3.ZERO, metal)
    rod(root, Vector3(-0.12, 0.0, 0.0), Vector3(0.12, 0.0, 0.0), radius * 0.16, dark)
    var spoke_count: int = 7 if motorcycle else 5
    for i in range(spoke_count):
        var t: float = TAU * float(i) / float(spoke_count)
        rod(root, Vector3(0.0, 0.0, 0.0), Vector3(0.0, cos(t) * radius * 0.65, sin(t) * radius * 0.65), 0.024, metal)
    if motorcycle:
        torus(root, radius * 0.39, radius * 0.47, Vector3(0.075, 0.0, 0.0), dark)
    return root

func car(color_index: int, van: bool = false) -> Node3D:
    var root := Node3D.new()
    var paint := material(paint_colors[color_index % paint_colors.size()], 0.60, 0.26)
    loft(root, [Vector4(-2.0, 0.65, 0.65, 0.16), Vector4(-1.7, 0.93, 0.67, 0.30), Vector4(1.5, 0.96, 0.69, 0.33), Vector4(2.0, 0.78, 0.70, 0.25)], paint)
    loft(root, [Vector4(-0.9, 0.70, 0.99, 0.12), Vector4(-0.3, 0.77, 1.18, 0.37), Vector4(0.95, 0.78, 1.20, 0.38), Vector4(1.55, 0.73, 1.04, 0.16)], glass)
    box(root, Vector3(1.38, 0.06, 1.20), Vector3(0.0, 1.57, 0.43), paint)
    for side in [-1.0, 1.0]:
        rod(root, Vector3(side * 0.75, 0.90, -0.8), Vector3(side * 0.74, 1.50, -0.25), 0.034, paint)
        rod(root, Vector3(side * 0.76, 0.92, 1.40), Vector3(side * 0.73, 1.51, 0.98), 0.043, paint)
        rod(root, Vector3(side * 0.79, 0.87, 0.35), Vector3(side * 0.76, 1.55, 0.35), 0.026, dark)
        box(root, Vector3(0.08, 0.055, 0.22), Vector3(side * 0.94, 0.88, 0.23), metal)
        ellipsoid(root, Vector3(0.16, 0.07, 0.18), Vector3(side * 1.02, 1.04, -0.62), paint, 12)
        for z in [-1.25, 1.25]:
            wheel(root, Vector3(side * 0.93, 0.40, z), 0.40)
        box(root, Vector3(0.42, 0.14, 0.06), Vector3(side * 0.55, 0.85, 1.98), taillight)
        box(root, Vector3(0.40, 0.13, 0.06), Vector3(side * 0.55, 0.78, -1.96), headlight)
    box(root, Vector3(1.45, 0.13, 0.12), Vector3(0.0, 0.43, 1.96), dark)
    box(root, Vector3(0.43, 0.16, 0.035), Vector3(0.0, 0.68, 2.03), material(Color("c5cbd1")))
    if van:
        root.scale.y = 1.15
    return root

func motorcycle() -> Node3D:
    var root := Node3D.new()
    wheel(root, Vector3(0.0, 0.42, 0.93), 0.42, true)
    wheel(root, Vector3(0.0, 0.42, -0.98), 0.42, true)
    # Frame, forks and swing arm.
    for side in [-1.0, 1.0]:
        rod(root, Vector3(side * 0.14, 0.48, 0.93), Vector3(side * 0.23, 0.69, -0.10), 0.055, dark)
        rod(root, Vector3(side * 0.16, 0.43, -0.98), Vector3(side * 0.18, 1.13, -0.52), 0.043, metal)
        rod(root, Vector3(side * 0.20, 0.67, -0.10), Vector3(side * 0.18, 1.04, -0.50), 0.035, red)
        rod(root, Vector3(side * 0.20, 0.67, -0.10), Vector3(side * 0.20, 1.02, 0.62), 0.032, red)
    ellipsoid(root, Vector3(0.24, 0.28, 0.32), Vector3(0.0, 0.67, 0.0), metal)
    loft(root, [Vector4(-1.00, 0.12, 1.05, 0.08), Vector4(-0.68, 0.34, 1.05, 0.20), Vector4(-0.18, 0.32, 0.85, 0.24), Vector4(0.12, 0.22, 0.77, 0.16)], red)
    ellipsoid(root, Vector3(0.30, 0.23, 0.42), Vector3(0.0, 1.12, -0.17), red, 24)
    ellipsoid(root, Vector3(0.25, 0.09, 0.39), Vector3(0.0, 1.12, 0.38), leather)
    loft(root, [Vector4(0.48, 0.25, 1.04, 0.10), Vector4(0.83, 0.28, 1.16, 0.12), Vector4(1.10, 0.13, 1.20, 0.07)], red)
    box(root, Vector3(0.29, 0.07, 0.055), Vector3(0.0, 1.18, 1.105), taillight)
    box(root, Vector3(0.22, 0.16, 0.04), Vector3(0.0, 0.84, 1.10), material(Color("c9d0d1")))
    ellipsoid(root, Vector3(0.24, 0.22, 0.035), Vector3(0.0, 1.28, -0.70), glass, 20)
    rod(root, Vector3(-0.47, 1.15, -0.45), Vector3(0.47, 1.15, -0.45), 0.035, dark)
    for side in [-1.0, 1.0]:
        rod(root, Vector3(side * 0.32, 1.20, -0.58), Vector3(side * 0.60, 1.36, -0.64), 0.020, metal)
        ellipsoid(root, Vector3(0.14, 0.075, 0.045), Vector3(side * 0.60, 1.36, -0.64), glass, 12)
    rod(root, Vector3(0.28, 0.53, 0.15), Vector3(0.35, 0.60, 0.85), 0.075, metal)
    # Rider: articulated boots, knees, arms, jacket and helmet.
    var trousers := material(Color("253343"), 0.0, 0.86)
    for side in [-1.0, 1.0]:
        ellipsoid(root, Vector3(0.15, 0.14, 0.32), Vector3(side * 0.25, 1.10, 0.35), trousers)
        rod(root, Vector3(side * 0.25, 1.13, 0.38), Vector3(side * 0.37, 0.87, -0.02), 0.12, trousers)
        rod(root, Vector3(side * 0.37, 0.87, -0.02), Vector3(side * 0.28, 0.61, 0.25), 0.085, trousers)
        ellipsoid(root, Vector3(0.10, 0.08, 0.21), Vector3(side * 0.28, 0.59, 0.10), leather)
        rod(root, Vector3(side * 0.27, 1.60, -0.22), Vector3(side * 0.36, 1.30, -0.25), 0.10, leather)
        rod(root, Vector3(side * 0.36, 1.30, -0.25), Vector3(side * 0.43, 1.15, -0.45), 0.075, leather)
        ellipsoid(root, Vector3(0.075, 0.07, 0.10), Vector3(side * 0.43, 1.15, -0.45), leather)
    var torso := ellipsoid(root, Vector3(0.30, 0.37, 0.18), Vector3(0.0, 1.44, 0.03), leather, 24)
    torso.rotation.x = -0.38
    rod(root, Vector3(0.0, 1.25, 0.22), Vector3(0.0, 1.65, 0.05), 0.025, material(Color("909ca7")))
    ellipsoid(root, Vector3(0.20, 0.24, 0.23), Vector3(0.0, 1.88, -0.23), dark, 24)
    ellipsoid(root, Vector3(0.205, 0.10, 0.08), Vector3(0.0, 1.90, -0.42), glass, 20)
    return root
