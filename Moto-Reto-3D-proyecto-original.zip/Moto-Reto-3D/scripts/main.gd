extends Node3D

const Race = preload("res://scripts/race.gd")
const Art = preload("res://scripts/art.gd")
const Landscape = preload("res://scripts/landscape.gd")
const HUD = preload("res://scripts/hud.gd")
var race = Race.new()
var art = Art.new()
var scenery = Landscape.new()
var hud = HUD.new()
var camera := Camera3D.new()
var bike: Node3D
var visuals: Dictionary = {}
var running: bool = false
var paused: bool = false
var saved: bool = false
var best: int = 0
var volume: float = 0.35
var steer_touch: int = -1
var mouse_steering: bool = false
var drive_touches: Dictionary = {}
var engine := AudioStreamPlayer.new()
var overtake := AudioStreamPlayer.new()
var crash := AudioStreamPlayer.new()
var engine_loop_position: float = 0.0
var capture: bool = false
var frame_count: int = 0
var elapsed_visual: float = 0.0

func _ready() -> void:
    Engine.max_fps = 60
    DisplayServer.window_set_title("Moto Reto 3D · Prueba real 0.2")
    get_tree().auto_accept_quit = false
    _load_state()
    add_child(scenery)
    bike = art.motorcycle()
    add_child(bike)
    add_child(camera)
    camera.position = Vector3(0.0, 2.85, 6.5)
    camera.fov = 68.0
    camera.near = 0.1
    camera.far = 650.0
    camera.current = true
    camera.look_at(Vector3(0.0, 1.15, -19.0), Vector3.UP)
    add_child(hud)
    hud.sound_slider.set_value_no_signal(volume)
    hud.play_requested.connect(_play)
    hud.pause_requested.connect(_pause)
    hud.volume_changed.connect(_change_volume)
    for entry in [[engine, "res://audio/engine.wav"], [overtake, "res://audio/overtake.wav"], [crash, "res://audio/crash.wav"]]:
        var player: AudioStreamPlayer = entry[0]
        player.stream = load(entry[1])
        add_child(player)
    engine.finished.connect(_loop_engine)
    _change_volume(volume)
    hud.show_menu("MOTO RETO 3D", "Desliza para conducir.\nAcelera, frena y supera tu récord.\nPrueba de gráficos 3D · 60 segundos", "JUGAR")
    capture = "--capture" in OS.get_cmdline_user_args()
    if capture:
        hud.hide_menu()
        race.traffic.clear()
        race.traffic.append({"id": 901, "x": -3.5, "z": 17.0, "speed": 55.0, "color": 3, "passed": false})
        race.traffic.append({"id": 902, "x": 3.5, "z": 33.0, "speed": 60.0, "color": 0, "passed": false})
        race.traffic.append({"id": 903, "x": 0.0, "z": 65.0, "speed": 58.0, "color": 2, "passed": false})
    _sync_traffic()
    _refresh()

func _play() -> void:
    if paused and not race.ended:
        paused = false
    else:
        race = Race.new(Time.get_ticks_usec())
        for v in visuals.values():
            v.queue_free()
        visuals.clear()
        paused = false
        saved = false
    running = true
    steer_touch = -1
    drive_touches.clear()
    mouse_steering = false
    hud.hide_menu()
    if volume > 0.0:
        engine.play()

func _pause() -> void:
    if not running or race.ended:
        return
    paused = true
    running = false
    steer_touch = -1
    drive_touches.clear()
    mouse_steering = false
    hud.gas = false
    hud.brake = false
    engine.stop()
    overtake.stop()
    hud.show_menu("PAUSA", "La partida está detenida.\nPuedes cambiar el volumen y continuar.", "CONTINUAR")

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        if is_instance_valid(hud) and hud.is_inside_tree():
            _pause()
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        if running:
            _pause()
        else:
            _save_state()
            get_tree().quit()
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        _save_state()
        get_tree().quit()

func _input(event: InputEvent) -> void:
    if not running or paused:
        return
    var size: Vector2 = get_viewport().get_visible_rect().size
    if event is InputEventScreenTouch:
        if not event.pressed:
            drive_touches.erase(event.index)
            if event.index == steer_touch:
                steer_touch = -1
        else:
            var role: String = hud.driving_role(event.position)
            drive_touches[event.index] = role
            if role == "steer" and steer_touch < 0 and event.position.y > 140.0 and event.position.y < size.y - 155.0:
                steer_touch = event.index
    elif event is InputEventScreenDrag and event.index == steer_touch:
        race.target_x = clampf(race.target_x + event.relative.x * 12.0 / size.x, -4.6, 4.6)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not OS.has_feature("android"):
        mouse_steering = event.pressed and event.position.y > 140.0 and event.position.y < size.y - 155.0
    elif event is InputEventMouseMotion and mouse_steering and not OS.has_feature("android"):
        race.target_x = clampf(race.target_x + event.relative.x * 12.0 / size.x, -4.6, 4.6)
    elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        _pause()

func _physics_process(dt: float) -> void:
    if not running or paused or capture:
        return
    if Input.is_physical_key_pressed(KEY_LEFT):
        race.target_x -= 5.5 * dt
    if Input.is_physical_key_pressed(KEY_RIGHT):
        race.target_x += 5.5 * dt
    race.update(dt, hud.gas or drive_touches.values().has("gas") or Input.is_physical_key_pressed(KEY_UP), hud.brake or drive_touches.values().has("brake") or Input.is_physical_key_pressed(KEY_DOWN))
    if race.next_close and volume > 0.0:
        overtake.play()
    scenery.move_world(race.distance, dt)
    bike.position.x = race.player_x
    bike.rotation.z = lerpf(bike.rotation.z, clampf((race.player_x - race.target_x) * 0.10, -0.22, 0.22), 0.15)
    bike.position.y = sin(race.distance * 1.3) * 0.006
    camera.position.x = lerpf(camera.position.x, race.player_x * 0.32, 0.05)
    camera.look_at(Vector3(race.player_x * 0.62, 1.15, -19.0), Vector3.UP)
    engine.pitch_scale = clampf(0.65 + race.speed / 180.0, 0.7, 1.8)
    _sync_traffic()
    _refresh()
    if race.ended and not saved:
        saved = true
        running = false
        hud.gas = false
        hud.brake = false
        engine.stop()
        if race.crashed and volume > 0.0:
            crash.play()
        best = maxi(best, race.points())
        _save_state()
        _refresh()
        var title: String = "FIN DE PARTIDA" if race.crashed else "¡RETO COMPLETADO!"
        var details: String = "%d puntos · récord %d\n%d adelantamientos · %d cercanos\nMejor cadena ×%d" % [race.points(), best, race.passes, race.close_passes, race.best_combo]
        hud.show_menu(title, details, "OTRA PARTIDA")

func _process(dt: float) -> void:
    elapsed_visual += dt
    frame_count += 1
    if capture and frame_count == 90:
        _capture_frame()

func _capture_frame() -> void:
    await RenderingServer.frame_post_draw
    var image: Image = get_viewport().get_texture().get_image()
    var target: String = OS.get_environment("MOTO_CAPTURE_PATH")
    if target.is_empty():
        target = "user://Moto-Reto-3D-Captura.png"
    var result: Error = image.save_png(target)
    image = null
    if result != OK:
        push_error("No se pudo guardar la captura: %s" % result)
    else:
        print("MOTO_CAPTURE_OK ", target)
    # Free the scene before shutting down the renderer and text servers.
    var tree: SceneTree = get_tree()
    set_process(false)
    set_physics_process(false)
    engine.stop()
    overtake.stop()
    crash.stop()
    var exit_code: int = 0 if result == OK else 1
    tree.create_timer(0.25).timeout.connect(tree.quit.bind(exit_code))
    queue_free()

func _sync_traffic() -> void:
    var active: Dictionary = {}
    for car in race.traffic:
        var id: int = int(car.id)
        active[id] = true
        if not visuals.has(id):
            var n: Node3D = art.car(int(car.color), int(car.color) == 1)
            visuals[id] = n
            add_child(n)
        var node: Node3D = visuals[id]
        node.position = Vector3(float(car.x), 0.0, -float(car.z))
    for id in visuals.keys():
        if not active.has(id):
            visuals[id].queue_free()
            visuals.erase(id)

func _refresh() -> void:
    hud.refresh(race.points(), best, maxi(0, int(ceil(Race.DURATION - race.elapsed))), race.speed, race.combo)

func _loop_engine() -> void:
    if running and not paused and volume > 0.0:
        engine.play()

func _change_volume(value: float) -> void:
    volume = clampf(value, 0.0, 1.0)
    for player in [engine, overtake, crash]:
        player.volume_db = linear_to_db(maxf(volume, 0.0001))
    engine.volume_db -= 12.0
    if volume == 0.0:
        engine.stop()
    elif running and not engine.playing:
        engine.play()
    _save_state()

func _load_state() -> void:
    var state := ConfigFile.new()
    if state.load("user://moto_reto.cfg") == OK:
        best = int(state.get_value("game", "best", 0))
        volume = clampf(float(state.get_value("sound", "volume", 0.35)), 0.0, 1.0)

func _save_state() -> void:
    var state := ConfigFile.new()
    state.set_value("game", "best", best)
    state.set_value("sound", "volume", volume)
    state.save("user://moto_reto.cfg")
