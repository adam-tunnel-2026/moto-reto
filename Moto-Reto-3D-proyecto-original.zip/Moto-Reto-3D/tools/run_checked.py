"""Fail CI on Godot script/shader/runtime errors even when the engine exits zero."""
import pathlib,re,subprocess,sys
try:
    result=subprocess.run(sys.argv[1:],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
except subprocess.TimeoutExpired as error:
    output=error.stdout or b''
    print(output.decode(errors='replace') if isinstance(output,bytes) else output,flush=True)
    raise SystemExit('Godot no terminó en 240 segundos. Se muestran sus registros anteriores.')
print(result.stdout,flush=True)
if result.returncode:
    raise SystemExit(result.returncode)
if re.search(r'(?:SCRIPT ERROR:|Parse Error:|SHADER ERROR:|ERROR:)',result.stdout,re.I):
    raise SystemExit('Godot registró un error. No se publica la APK.')
if 'res://tests/race_test.gd' in sys.argv and 'MOTO_TEST_OK:' not in result.stdout:
    raise SystemExit('Las pruebas no llegaron al final. No se publica la APK.')
